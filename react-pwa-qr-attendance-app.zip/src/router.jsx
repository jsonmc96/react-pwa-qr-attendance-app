import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { RoleGuard } from './components/auth/RoleGuard';
import { LoginPage } from './pages/LoginPage';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { GenerateQR } from './pages/admin/GenerateQR';
import { AttendanceReport } from './pages/admin/AttendanceReport';
import { QRHistoryPage } from './pages/admin/QRHistoryPage';
import { AdminSettings } from './pages/admin/AdminSettings';
import { UserDashboard } from './pages/user/UserDashboard';
import { ScanQR } from './pages/user/ScanQR';
import { MyAttendance } from './pages/user/MyAttendance';
import { RankingPage } from './pages/shared/RankingPage';
import { ROUTES, ROLES } from './utils/constants';
import { useAuth } from './context/AuthContext';
import { MainLayout } from './components/layout/MainLayout';

export const AppRouter = () => {
    const { user, loading } = useAuth();

    if (loading) {
        // return null; // O un loading screen
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-10 w-10 border-4 border-gray-300 border-t-gray-900 mx-auto" />
                    <p className="mt-3 text-gray-600">Cargando...</p>
                </div>
            </div>
        );
    }

    return (
        <BrowserRouter>
            <Routes>
                {/* Ruta pública */}
                <Route
                    path={ROUTES.LOGIN}
                    element={
                        user ? (
                            <Navigate to={user.role === ROLES.ADMIN ? ROUTES.ADMIN_DASHBOARD : ROUTES.USER_DASHBOARD} replace />
                        ) : (
                            <LoginPage />
                        )
                    }
                />

                {/* Rutas Protegidas con Layout Persistente */}
                <Route element={
                    <ProtectedRoute>
                        <MainLayout />
                    </ProtectedRoute>
                }>
                    {/* Rutas de Admin */}
                    <Route
                        path={ROUTES.ADMIN_DASHBOARD}
                        element={
                            <RoleGuard allowedRole={ROLES.ADMIN}>
                                <AdminDashboard />
                            </RoleGuard>
                        }
                    />
                    <Route
                        path={ROUTES.ADMIN_GENERATE_QR}
                        element={
                            <RoleGuard allowedRole={ROLES.ADMIN}>
                                <GenerateQR />
                            </RoleGuard>
                        }
                    />
                    <Route
                        path="/admin/qr-history"
                        element={
                            <RoleGuard allowedRole={ROLES.ADMIN}>
                                <QRHistoryPage />
                            </RoleGuard>
                        }
                    />
                    <Route
                        path={ROUTES.ADMIN_REPORTS}
                        element={
                            <RoleGuard allowedRole={ROLES.ADMIN}>
                                <AttendanceReport />
                            </RoleGuard>
                        }
                    />
                    <Route
                        path="/admin/settings"
                        element={
                            <RoleGuard allowedRole={ROLES.ADMIN}>
                                <AdminSettings />
                            </RoleGuard>
                        }
                    />
                    <Route
                        path={ROUTES.RANKING}
                        element={
                            <div className="pb-safe">
                                <RoleGuard allowedRole={[ROLES.ADMIN, ROLES.USER]}>
                                    <RankingPage />
                                </RoleGuard>
                            </div>
                        }
                    />

                    {/* Rutas de Usuario */}
                    <Route
                        path={ROUTES.USER_DASHBOARD}
                        element={
                            <RoleGuard allowedRole={ROLES.USER}>
                                <UserDashboard />
                            </RoleGuard>
                        }
                    />
                    <Route
                        path={ROUTES.USER_SCAN_QR}
                        element={
                            <RoleGuard allowedRole={[ROLES.USER, ROLES.ADMIN]}>
                                <ScanQR />
                            </RoleGuard>
                        }
                    />
                    <Route
                        path={ROUTES.USER_ATTENDANCE}
                        element={
                            <RoleGuard allowedRole={[ROLES.USER, ROLES.ADMIN]}>
                                <MyAttendance />
                            </RoleGuard>
                        }
                    />
                </Route>

                {/* Ruta por defecto */}
                <Route
                    path="/"
                    element={
                        <Navigate
                            to={user ? (user.role === ROLES.ADMIN ? ROUTES.ADMIN_DASHBOARD : ROUTES.USER_DASHBOARD) : ROUTES.LOGIN}
                            replace
                        />
                    }
                />

                {/* 404 */}
                <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
        </BrowserRouter>
    );
};
